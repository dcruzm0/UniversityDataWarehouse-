﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Registration
{
    public class Database
    {
        private string connectionString = "";
        SqlConnection con;
        public Database()
        {


            //connectionString = "Server = MARK-DS-PC; Database = 391Project; Trusted_Connection = yes; ";
            connectionString = @"Data Source=(LocalDB)\MSSQLLOCALDB; AttachDbFilename =|DataDirectory|\institute.mdf; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        public int Execute(string sql, List<SqlParameter> sqlParameters = null)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(sql, con);
                if (sqlParameters != null)
                {
                    cmd.Parameters.AddRange(sqlParameters.ToArray());
                }
                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }
            finally
            {
                con.Close();
            }
            return 0;
        }

        public DataTable Read(string sql, List<SqlParameter> sqlParameters = null)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(sql, con);
                if (sqlParameters != null)
                {
                    cmd.Parameters.AddRange(sqlParameters.ToArray());
                }
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }
            finally { con.Close(); }
            return null;
        }

        public int ExecuteTran(string sql)
        {
            try
            {
                con.Open();
                SqlTransaction transaction = con.BeginTransaction("Sample");
                //SqlCommand cmd = new SqlCommand(sql, con);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.Transaction = transaction;
                try
                {
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    Console.WriteLine("Transaction complete");
                    return cmd.ExecuteNonQuery();
                }
                catch(Exception ex)
                {
                    Console.WriteLine("Transaction error");
                    try
                    {
                        transaction.Rollback();
                        return 0;

                    }
                    catch(Exception ex2)
                    {
                        Console.WriteLine("Roleback error");
                        return 0;
                    }
                }
                
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }
            finally
            {
                con.Close();
            }
            return 0;
        }

        public static string ErrorMessage { get; set; }
    }
}
