﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Registration
{
 
    public partial class Form1 : Form
    {
        public SqlCommand myCommand;
        public Form1()
        {
            InitializeComponent();
            myCommand = new SqlCommand();
        }
        Database db = new Database();
        course[] courses=new course[50];
        int section_id=0;
        List<int> section = new List<int>();
        int department_id=0;
        string schedule = "";

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if ((int.Parse(txtUsername.Text) > 0) && (int.Parse(txtUsername.Text) <= 50) && txtUsername.Text == txtPassword.Text)
                {
                    panel1.Visible = true;

                    string sql = "Select * from Course";
                    DataTable dt = db.Read(sql);
                    int i = 0;
                    foreach (DataRow dataRow in dt.Rows)
                    {
                        courses[i] = new course();
                        comboBox1.Items.Add(dataRow[1].ToString());
                        courses[i].Name = dataRow[1].ToString();
                        courses[i].id = int.Parse(dataRow[0].ToString());
                        i++;
                    }
                    comboBox1.SelectedIndex = 1;
                    sql = "Select section_id from section_taken where student_id=" + txtPassword.Text;
                    dt = null;
                    dt = db.Read(sql);
                    foreach (DataRow dataRow1 in dt.Rows)
                    {
                        sql = "Select course_id from section where section_id=" + dataRow1[0].ToString();
                        DataTable temp = db.Read(sql);
                        foreach (DataRow dataRow in temp.Rows)
                        {
                            sql = "Select course_name from course where course_id=" + dataRow[0].ToString();
                            temp = db.Read(sql);
                            foreach (DataRow dr in temp.Rows)
                            {
                                label4.Text += dr[0].ToString() + ",";

                            }
                        }
                    }

                    string sql2 = "Select * from section_taken where student_id=" + txtPassword.Text;
                    SqlCommand cmd = new SqlCommand(sql2);
                    SqlDataAdapter dAdapter = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    dAdapter.Fill(ds);
                    takenGrid.DataSource = ds.Tables[8];
                    DataTable dt2 = new DataTable();
                    dt2 = db.Read(sql);
                    
                }
                else
                {
                    MessageBox.Show("Wrong Credentials 1");
                }
            }
            catch (Exception ex)
            {

                //MessageBox.Show("Wrong Credentails 2");
            }
            tableRefresh();


        }
        

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'instituteDataSet.Section_Taken' table. You can move, or remove it, as needed.
            //this.section_TakenTableAdapter.Fill(this.instituteDataSet.Section_Taken);



        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void lblDepartment_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            section.Clear();
            dgv1.Rows.Clear();
            //string sql = "SELECT section.*, instructor.Instructor_name,instructor.Department_id FROM section INNER JOIN course ON course.Course_id = section.Course_id INNER JOIN instructor ON course.Instructor_id = instructor.Instructor_id where course.Course_id =" + courses[comboBox1.SelectedIndex].id;
            string sql = "EXEC Proc1 @CourseID = " + (courses[comboBox1.SelectedIndex].id).ToString();
            DataTable dt = db.Read(sql);
            foreach (DataRow dataRow in dt.Rows)
            {
                section_id = int.Parse(dataRow[0].ToString());
                section.Add(section_id);
                dgv1.Rows.Add(dataRow[1].ToString(), dataRow[2].ToString(), dataRow[4].ToString(), dataRow[5].ToString());
                department_id = int.Parse( dataRow[6].ToString());
                schedule = dataRow[4].ToString();
            }

            sql = "Select Department_Name from Department where id=" + department_id;
            dt = null;
            dt = db.Read(sql);
          
            foreach (DataRow dataRow in dt.Rows)
            {
                lblDepartment.Text = dataRow[0].ToString();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int s = dgv1.CurrentCell.RowIndex;
            s = section[s];
            string[] courses_taken = label4.Text.Split(',');

            string course = comboBox1.Text;

            if (courses_taken.Contains(course))
            {
                MessageBox.Show("Course Already Taken");

            }
            else
            {
                string sql = "EXEC GetPreReq @CourseID = " + s.ToString();
                //string sql = "Select Pre_Requisite from Course where course_id=" + s;
                DataTable dt = db.Read(sql);
                int id = 0;
                foreach (DataRow dr in dt.Rows)
                {
                    id = int.Parse(dr[0].ToString());
                }
                //add if id=0 then register
                if (id == 0)
                {
                    sql = "select section_id from section_taken where student_id=" + txtUsername.Text;
                    dt = null;
                    dt = db.Read(sql);
                    int[] section = new int[dt.Rows.Count];
                    int i = 0;
                    foreach (DataRow dataRow in dt.Rows)
                    {
                        section[i] = int.Parse(dataRow[0].ToString());
                        i++;
                    }
                    bool flag = false;
                    for (int j = 0; j < section.Length; j++)
                    {
                        sql = "select Time_slot from Section where section_id=" + section[j];
                        dt = null;
                        dt = db.Read(sql);

                        foreach (DataRow dr in dt.Rows)
                        {
                            if (schedule == dr[0].ToString())
                            {
                                MessageBox.Show("Time Slot Clash");
                                flag = true;
                            }
                        }
                        if (flag == true)
                        {
                            break;
                        }


                    }
                    if (flag == false)
                    {
                        sql = "Insert into Section_Taken values(" + txtUsername.Text + "," + section_id + ")";
                        int output = db.Execute(sql);
                        if (output == 0)
                        {
                            MessageBox.Show(Database.ErrorMessage);
                        }
                        else
                        {
                            MessageBox.Show("Course Enrolled");
                            
                        }
                    }

                }
                else
                {

                    sql = "Select * from Section_Taken where section_id=" + id + " and student_id=" + txtUsername.Text;
                    dt = null;
                    dt = db.Read(sql);
                    if (dt.Rows.Count == 0)
                    {
                        sql = "Select Course_Name from Course Where course_id=" + id;
                        dt = null;
                        dt = db.Read(sql);
                         course = "";
                        foreach (DataRow dataRow in dt.Rows)
                        {
                            course = dataRow[0].ToString();
                        }
                        MessageBox.Show("Pre Requisite :" + course + " Not Taken");
                        //message box with pre requisite name
                    }
                    else
                    {
                        sql = "Select * from Section_Taken where section_id=" + section_id;
                        dt = null;
                        dt = db.Read(sql);
                        int count = dt.Rows.Count;
                        sql = "Select capacity from section where section_id=" + section_id;
                        dt = null;
                        int capacity = 0;
                        dt = db.Read(sql);
                        foreach (DataRow dataRow in dt.Rows)
                        {
                           capacity = int.Parse(dataRow[0].ToString());
                        }
                        if (count >= capacity)
                        {
                            MessageBox.Show("Section Full" + count.ToString());
                        }
                        else
                        {
                            sql = "select section_id from section_taken where student_id=" + txtUsername.Text;
                            dt = null;
                            dt = db.Read(sql);
                            int[] section = new int[dt.Rows.Count];
                            int i = 0;
                            foreach (DataRow dataRow in dt.Rows)
                            {
                                section[i] = int.Parse(dataRow[0].ToString());
                                i++;
                            }
                            bool flag = false;
                            for (int j = 0; j < section.Length; j++)
                            {
                                sql = "select Time_slot from Section where section_id=" + section[j];
                                dt = null;
                                dt = db.Read(sql);

                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (schedule == dr[0].ToString())
                                    {
                                        MessageBox.Show("Time Slot Clash");
                                        flag = true;
                                    }
                                }


                            }
                            if (flag == false)
                            {

                                sql = "Insert into Section_Taken values(" + txtUsername.Text + "," + section_id + ")";
                                int output = db.ExecuteTran(sql);
                                if (output == 0)
                                {
                                    MessageBox.Show(Database.ErrorMessage);
                                }
                                else
                                {
                                    MessageBox.Show("Course Enrolled");
                                    tableRefresh();
                                    
                                }
                            }

                        }

                    }
                }
            }
              
          
            
        }
        public void tableRefresh()
        {
            /*string comm = "select * " +
                 "from section_taken S, Course C" +
                 "where student_id='" + txtPassword.Text + "' and S.Course = C.Section";
            string comm = "SELECT C.COurse_name " +
                "FROM Section_Taken S1, Section S3, Course C " +
                "WHERE S1.Student_id = '" + txtPassword.Text + "' and S1.Section_id = S3.Section_id and C.Course_id = S3.Course_id;";
            /*string comm = "SELECT C.COurse_name" +
                "FROM Section_Taken S1, Section S3, Course C" +
                "WHERE S1.Student_id ='" + txtUsername.Text + "' and S1.Section_id = S3.Section_id and C.Course_id = S3.Course_id;";
            */
            string comm = "EXEC GetAllCourseName @StudentID = '" + txtPassword.Text + "'";
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLOCALDB; AttachDbFilename =|DataDirectory|\institute.mdf; Integrated Security = True");
            SqlCommand cmd = new SqlCommand(comm , conn);
            try
            {
                SqlDataAdapter sqlDataAdap = new SqlDataAdapter(cmd);
                DataTable dtRecord = new DataTable();
                sqlDataAdap.Fill(dtRecord);
                takenGrid.DataSource = dtRecord;
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString(), "Error");
            }
        }
    }
    public class course
    {
        public int id { get; set; }

        public string Name { get; set; }

    }
}
