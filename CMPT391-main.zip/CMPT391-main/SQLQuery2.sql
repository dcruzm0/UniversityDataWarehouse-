USE [NewDatabase]

CREATE TABLE [Student](
	[StudentID] [varchar](25) NOT NULL,
	[Name] [varchar](50) NULL,
	[TotalCredits] [int] NULL,
	[DepartmentName] [varchar](25) NULL,
	PRIMARY KEY (StudentID),
	)

CREATE TABLE [Takes](
	[StudentID] [varchar](25) NOT NULL,
	[SectionID] [varchar](25) NOT NULL,
	PRIMARY KEY (StudentID, SectionID),
	)


CREATE TABLE Section(
	[SectionID] [varchar](25) NOT NULL,
	[Semester] [varchar](25) NOT NULL,
	[Capacity] [int] NULL,
	[Year] [varchar](25) NULL,
	[Enrolled] [int] NULL,
	[CourseID] [varchar](25) NOT NULL,
	[InstructorID] [varchar](25) NOT NULL,
	[Time] [varchar](25) NOT NULL,   
	PRIMARY KEY (SectionID)
	)


CREATE TABLE [Course](
	[CourseID] [varchar](25) NOT NULL,
	[CourseName] [varchar](25) NOT NULL,
	[Credits] [int] NOT NULL,
	[Depart] [varchar](25) NOT NULL,
	[ReqID] [varchar] (20) NULL,
	PRIMARY KEY ([CourseID]) 
	)

CREATE TABLE [Instructor](
	[InstructorID] [varchar](25) NOT NULL,
	[IName] [varchar](25) NOT NULL,
	[DepartmentName] [varchar](25) NOT NULL,
	PRIMARY KEY (InstructorID)
	)

CREATE TABLE [Department](
	[DepartmentName] [varchar](25) NOT NULL,
	[Building] [varchar](25) NOT NULL,
	PRIMARY KEY (DepartmentName),
	) 

DROP TABLE Student;
DROP TABLE Instructor;
DROP TABLE Department;
DROP TABLE Course;
DROP TABLE Section;
DROP TABLE Takes;

USE [Project]

DELETE FROM Student;
DELETE FROM Instructor;
DELETE FROM Department;
DELETE FROM Course;
DELETE FROM Section;
DELETE FROM Takes;



/****  Student ****/
Insert into Student values ('1', 'Mark', 50, 'CompSci');
Insert into Student values ('2', 'Ben', 100, 'Art');
Insert into Student values ('3', 'Beth',60, 'Math');
Insert into Student values ('4', 'Joe', 10, 'Biology');
Insert into Student values ('5', 'Jane', 120, 'CompSci');

Insert into Section values ('1', 'Fall', 30, '2023', 20, '1', '1', 'MWF AM');
Insert into Section values ('2', 'Fall', 35, '2023', 35, '2', '1', 'MWF PM');
Insert into Section values ('3', 'Fall', 20, '2023', 15, '3', '2','TT AM');
Insert into Section values ('4', 'Fall', 30, '2023', 29, '4', '3','TT AM');
Insert into Section values ('5', 'Fall', 20, '2023', 0, '5', '4','TT PM');
Insert into Section values ('6', 'Winter', 20, '2024', 20, '1', '2', 'MWF PM');
Insert into Section values ('7', 'Winter', 40, '2024', 30, '5', '3','TT AM');
Insert into Section values ('8', 'Winter', 40, '2024', 20, '6', '4','TT PM');
Insert into Section values ('9', 'Winter', 10, '2024', 10, '3', '4', 'MWF AM');

Insert into Course values ('1', 'Name1', 3, 'CompSci', null);
Insert into Course values ('2', 'Name2', 3, 'CompSci', '2');
Insert into Course values ('3', 'Name3', 3, 'Art', null);
Insert into Course values ('4', 'Name4', 3, 'Math', null);
Insert into Course values ('5', 'Name5', 3, 'Biology', null);
Insert into Course values ('6', 'Name6', 3, 'Biology', '5');

Insert into Takes values ('1', '1');
Insert into Takes values ('2', '1');
Insert into Takes values ('3', '1');
Insert into Takes values ('2', '3');
Insert into Takes values ('2', '4');
Insert into Takes values ('5', '7');
Insert into Takes values ('5', '4');

Insert into Instructor values ('1', 'Turing', 'CompSci');
Insert into Instructor values ('2', 'Ren', 'Art');
Insert into Instructor values ('3', 'Coloumb', 'Biology');
Insert into Instructor values ('4', 'Feuler', 'Math');

Insert into Department values('CompSci', '5');
Insert into Department values('Art', '11');
Insert into Department values('Biology', '7');
Insert into Department values('Math', '5');

SELECT *
FROM Student;

SELECT *
FROM Instructor;


CREATE PROCEDURE GetTakenCourseID @ID nvarchar(10), @Year nvarchar(10), @Semester nvarchar(10)
AS
BEGIN
	SELECT Course.CourseID
	FROM Student, Section, Takes, Course
	WHERE Student.StudentID = @ID and Student.StudentID = Takes.StudentID and
		Section.SectionID = Takes.SectionID and Section.CourseID = Course.CourseID and 
		[Year] = @Year and Section.Semester = @Semester;
END;

CREATE PROCEDURE GetEnrollAndCap @SectionID nvarchar(10)
AS
BEGIN
	SELECT Enrolled, Capacity
	from Section
	WHERE SectionID = @SectionID
END;

CREATE PROCEDURE GetTime @SectionID nvarchar(10)
AS
BEGIN
	SELECT [Time]
	FROM Section
	WHERE SectionID = @SectionID
END;

CREATE PROCEDURE GetCourseReq @CourseID nvarchar(10)
AS
BEGIN
	SELECT [ReqID]
	FROM Course
	WHERE CourseID = @CourseID
END;

/* Get enrollment and capacity */
EXEC GetEnrollAndCap @SectionID = '1';
/* Get taken course id */
EXEC GetTakenCourseID @Year = '2023', @Semester = 'Fall', @ID = '2';
/* Get Section Time Slot */
EXEC GetTime @SectionID = '2';
/* Get Course Requirements */
EXEC GetCourseReq @CourseID = '2';
